function googleTranslateElementInit() {
      
    new google.translate.TranslateElement({

        pageLanguage: 'pt',

        autoDisplay: 'true',
       
        includedLanguages:'en',
     
      layout: google.translate.TranslateElement.InlineLayout.SIMPLE

    }, 'google_translate_element');

  }


